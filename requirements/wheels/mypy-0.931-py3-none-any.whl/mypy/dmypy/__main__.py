from mypy.dmypy.client import console_entry

if __name__ == '__main__':
    console_entry()
